#!/bin/sh

cd SPU
spuxlc -O3 -qmakedep=gcc -o SPU *.c 
cd ..
cp SPU/SPU PPU/SPU
cd PPU
ppu-embedspu SPU SPU SPU.o
ppuxlc -O3 -q64 -qmakedep=gcc -o PPU *.c SPU.o -lspe2 -lpthread
cd ..
cp PPU/PPU ../binary/PPU

