#include "ppu.h"
#include "ppu_prof.h"



void *spe_start(void *p)
{
	int ret;
	unsigned int entry;
	spe_stop_info_t stop_info;
	spe_program_handle_t *program;
	int rc;
	spe_t *spe=(spe_t *)p;

	program=&SPU;
	entry=SPE_DEFAULT_ENTRY;
	spe->ctx = spe_context_create(0, NULL);
	assert(spe->ctx != NULL);
	ret = spe_program_load(spe->ctx, program);
	assert( ret == 0 );
	rc = spe_context_run(spe->ctx, &entry, 0, &(spe->p), NULL, &stop_info);
	if (rc < 0)
		perror("spe_context_run");
	spe_context_destroy(spe->ctx);
	pthread_exit(NULL);
}


void waitall(spe_t spe[NUMSPE], unsigned int m)
{
	unsigned int mes;
	int i;
	for(i=0;i<NUMSPE;i++)
	{
		mes=NONE;
		do {
			while(spe_out_mbox_status(spe[i].ctx)==0);
			spe_out_mbox_read(spe[i].ctx,&mes,1);
		}while(mes!=m);
	}
}


void sendall(spe_t spe[NUMSPE], unsigned int m)
{
	int i;
	for(i=0;i<NUMSPE;i++)
		spe_in_mbox_write(spe[i].ctx, &m, 1, SPE_MBOX_ALL_BLOCKING);
}

void initspe(spe_t spe[NUMSPE])
{
	int i;
	unsigned int mes;

	for(i=0;i<NUMSPE;i++)
	{
		spe[i].ctx=NULL;
		spe[i].p.id=i;
		spe[i].p.cmdjp=(unsigned long long)&(spe[i].cmdjp);
		spe[i].p.cmdcf=(unsigned long long)&(spe[i].cmdcf);
		spe[i].p.psig1=(unsigned long long)&(spe[i].psig1);
		spe[i].p.psig2=(unsigned long long)&(spe[i].psig2);
		pthread_create(&(spe[i].pth),NULL,spe_start,(void *)&(spe[i]));
	}

	waitall(spe, IDLE);

#ifdef PPEDEBUG
	fprintf(stderr, "PPEDEBUG:SPE Start\n");
#endif	
}


void setjp(spe_t spe[NUMSPE], int n, double mj[NMAX], double xj[NMAX], double yj[NMAX], double zj[NMAX])
{
	unsigned int mode=SETJP;
	int i, index=0, nj, ns, a, b;
	static volatile float mjb[NMAX] __ALIGNED_DMA__;
	static volatile float xjb[NMAX] __ALIGNED_DMA__;
	static volatile float yjb[NMAX] __ALIGNED_DMA__;
	static volatile float zjb[NMAX] __ALIGNED_DMA__;
	ns=(n+JSET-1)/JSET;
	b=(ns+(NUMSPE-1))/NUMSPE;
	nj=JSET*b;
	a=ns-(b-1)*NUMSPE;
	for(i=0;i<n;i++)
	{
		mjb[i]=mj[i];
		xjb[i]=xj[i];
		yjb[i]=yj[i];
		zjb[i]=zj[i];
	}
	for(i=0;i<NUMSPE;i++)
	{
		if(i==a)
			nj-=JSET;
		spe[i].cmdjp.nj=nj;
		spe[i].cmdjp.mj=(unsigned long long)&mjb[index];
		spe[i].cmdjp.xj=(unsigned long long)&xjb[index];
		spe[i].cmdjp.yj=(unsigned long long)&yjb[index];
		spe[i].cmdjp.zj=(unsigned long long)&zjb[index];
#ifdef PPEDEBUG
		fprintf(stderr, "PPEDEBUG:%d SETJP %d %lf %lf %lf\n", i, index, xj[index], yj[index], zj[index]);
#endif	
		index+=nj;
	}
	sendall(spe, mode);
#ifdef PPEDEBUG
	fprintf(stderr, "PPEDEBUG:SETJP\n");
#endif	
	waitall(spe, ENDJP);
}


void calcforce(spe_t spe[NUMSPE], int n, double eps2, double xi[NMAX], double yi[NMAX], double zi[NMAX],
				 double pot[NMAX], double ax[NMAX], double ay[NMAX], double az[NMAX])
{
	int i, j, k=0, num=0, nold=0, buf=0, offset=0, nr=n;
	unsigned int mode=CALCFORCE;
	static volatile float xb[NMAX] __ALIGNED_DMA__;
	static volatile float yb[NMAX] __ALIGNED_DMA__;
	static volatile float zb[NMAX] __ALIGNED_DMA__;
	static volatile float potb[NUMSPE][IBUF] __ALIGNED_DMA__;
	static volatile float axb[NUMSPE][IBUF] __ALIGNED_DMA__;
	static volatile float ayb[NUMSPE][IBUF] __ALIGNED_DMA__;
	static volatile float azb[NUMSPE][IBUF] __ALIGNED_DMA__;
	volatile unsigned int *ps[6][2];

	for(i=0;i<n;i++)
	{
		xb[i]=xi[i];
		yb[i]=yi[i];
		zb[i]=zi[i];
	}
	for(i=0;i<NUMSPE;i++)
	{
		spe[i].cmdcf.ni=n;
		spe[i].cmdcf.eps2=eps2;
		spe[i].cmdcf.xi=(unsigned long long)&(xb[0]);
		spe[i].cmdcf.yi=(unsigned long long)&(yb[0]);
		spe[i].cmdcf.zi=(unsigned long long)&(zb[0]);
		spe[i].cmdcf.pot=(unsigned long long)&(potb[i][0]);
		spe[i].cmdcf.ax=(unsigned long long)&(axb[i][0]);
		spe[i].cmdcf.ay=(unsigned long long)&(ayb[i][0]);
		spe[i].cmdcf.az=(unsigned long long)&(azb[i][0]);
		ps[i][0]=&(spe[i].psig1);
		ps[i][1]=&(spe[i].psig2);
		*ps[i][0]=NONE;
		*ps[i][1]=NONE;
	}
	sendall(spe, mode);
#ifdef PPEDEBUG
	fprintf(stderr, "PPEDEBUG:CALCFORCE\n");
#endif	

	for(j=0;j<n;j++)
		pot[j]=0.0f, ax[j]=0.0f, ay[j]=0.0f, az[j]=0.0f;

	for(j=0;j<n;j+=ISET)
	{
		offset=buf*ISET;

#ifdef PPEDEBUG
		fprintf(stderr, "PPEDEBUG: wait ENDPUT buf=%d, %d\n", buf, j);
#endif
		for(k=0;k<NUMSPE;k++)
			while(*ps[k][buf]!=ENDPUT);
#ifdef PPEDEBUG
		fprintf(stderr, "PPEDEBUG: ENDPUT buf=%d %d\n", buf, j);
#endif

		for(k=0;k<NUMSPE;k++)
		{
			for(i=0;i<(nr>ISET?ISET:nr);i++) // add
			{
				pot[j+i]+=(double)potb[k][offset+i];
				ax[j+i]+=(double)axb[k][offset+i];
				ay[j+i]+=(double)ayb[k][offset+i];
				az[j+i]+=(double)azb[k][offset+i];
			}
			*ps[k][buf]=NONE;
		}
		for(i=0;i<(nr>ISET?ISET:nr);i++)
		{
			pot[j+i]*=POTCOR;
			ax[j+i]*=ACCCOR;
			ay[j+i]*=ACCCOR;
			az[j+i]*=ACCCOR;
		}
		nr-=ISET;
		buf^=1;
	}
	waitall(spe, ENDCF);
#ifdef PPEDEBUG
	fprintf(stderr, "PPEDEBUG:END CALCFORCE\n");
#endif		
}


void finalize(spe_t spe[NUMSPE])
{
	unsigned int mode=FINISH;
	int i;
	sendall(spe, mode);
	for(i=0;i<NUMSPE;i++)
	{
		pthread_join(spe[i].pth,(void *)NULL);
#ifdef PPEDEBUG
		fprintf(stderr, "PPEDEBUG:SPE %d Stopped\n", i);
#endif
	}
}


