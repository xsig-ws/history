#include "spu.h"


int main(unsigned long long id, unsigned long long argp, unsigned long long envp)
{
	static float	mj[JMAX]		__ALIGNED_DMA__;
	static float	xj[JMAX]		__ALIGNED_DMA__;
	static float	yj[JMAX]		__ALIGNED_DMA__;
	static float	zj[JMAX]		__ALIGNED_DMA__;
	unsigned int mode=NONE;

	params_t p __ALIGNED_16__;
	cmdjp_t cmdjp __ALIGNED_16__;
	cmdcf_t cmdcf __ALIGNED_16__;

	dma_get(argp, &p, sizeof(params_t), 1);
	dma_wait(1);

	spu_write_out_mbox(IDLE);
#ifdef SPEDEBUG
	fprintf(stderr, "SPEDEBUG:SPE %d Started\n", p.id);
#endif
	while(1)
	{
		if(spu_stat_in_mbox()>0)
			mode=spu_read_in_mbox();

		if(mode==SETJP) // (and predict)
		{
			dma_get(p.cmdjp, &cmdjp, sizeof(cmdjp_t), 1);
			dma_wait(1);
			loadjp(cmdjp, mj, xj, yj, zj);
#ifdef SPEDEBUG2
			fprintf(stderr, "SPEDEBUG:SPE %d load j-particle %d %e %e %e %e\n", p.id, cmdjp.nj,
					 mj[cmdjp.nj-1], xj[cmdjp.nj-1], yj[cmdjp.nj-1], zj[cmdjp.nj-1]);
#endif
			mode=WAIT;
			spu_write_out_mbox(ENDJP);
			continue;
		}
		if(mode==CALCFORCE)
		{
			dma_get(p.cmdcf, &cmdcf, sizeof(cmdcf_t), 1);
			dma_wait(1);
#ifdef SPEDEBUG
			fprintf(stderr, "SPEDEBUG:SPE %d CALCFORCE %d\n", p.id, cmdcf.ni);
#endif
			calcforce(p, cmdcf, cmdjp.nj, mj, xj, yj, zj);
#ifdef SPEDEBUG
			fprintf(stderr, "SPEDEBUG:SPE %d END CALCFORCE %d\n", p.id, cmdcf.ni);
#endif
			spu_write_out_mbox(ENDCF);
			mode=WAIT;
			continue;
		}
		if(mode==FINISH)
		{
			spu_write_out_mbox(FINISH);
			break;
		}
	}
#ifdef SPEDEBUG
	fprintf(stderr, "SPEDEBUG:SPE %d FINISH\n", p.id);
#endif
	return 0;
}
