#ifndef PARAMS_H_
#define PARAMS_H_

#define	TMAX	0.5
#define 	DT		(0.03125)

#endif
