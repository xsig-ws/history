#ifndef SPU_H_
#define SPU_H_

#define SPEDEBUG_
#define COREDEBUG_
#define PAIRDEBUG_
#define ROUNDUP

#include "../PPU/common.h"
#include "../PPU/command.h"


#include <stdio.h>
#include <stdlib.h>
#include <spu_intrinsics.h>
#include <spu_mfcio.h>
#include <simdmath.h>
#include <simdmath/rsqrtf4.h>
#include <math.h>
#include <float.h>
#include <assert.h>


void loadjp(cmdjp_t cmdjp, float mj[JMAX], float xj[JMAX], float yj[JMAX], float zj[JMAX]);
void calcforce_core(int id, int buf, int ns, float eps2, float xi[IBUF], float yi[IBUF], float zi[IBUF],
					  int nj, float mj[JMAX], float xj[JMAX], float yj[JMAX], float zj[JMAX],
					  float pot[IBUF], float ax[IBUF], float ay[IBUF], float az[IBUF]);
void calcforce(params_t p, cmdcf_t cf, int nj, float mj[JMAX], float xj[JMAX], float yj[JMAX], float zj[JMAX]);

void dma_get(unsigned long long ea, volatile void *lsa, int size, int tag);
void dma_put(void *lsa, unsigned long long ea, int size, int tag);
void dma_put_fence(void *lsa, unsigned long long ea, int size, int tag);
void dma_wait(int tag);

#endif /*SPU_H_*/
