#include "ppu.h"

void readnemo(char *fn, int *n, double m[NMAX], double x[NMAX], double y[NMAX], double z[NMAX],
				double vx[NMAX], double vy[NMAX], double vz[NMAX])
{
	int dim, i, nt;
	double t;
	FILE *in;

	if((in=fopen(fn, "r"))==NULL)
	{
		fprintf(stderr, "%s not found.\n", fn);
		exit(1);
	}

	fscanf(in, "%d%d%lf",&nt,&dim,&t);
	if(nt>NMAX)
	{
		fprintf(stderr, "too many particles.\n");
		fclose(in);
		exit(1);
	}
	*n=nt;
	for(i=0;i<*n;i++)
		fscanf(in, "%lf", &m[i]);
	for(i=0;i<*n;i++)
		fscanf(in, "%lf%lf%lf", &x[i], &y[i], &z[i]);
	for(i=0;i<*n;i++)
		fscanf(in, "%lf%lf%lf", &vx[i], &vy[i], &vz[i]);
	fclose(in);
}


void writenemo(char *fn, int n, double t, double m[NMAX], double x[NMAX], double y[NMAX], double z[NMAX],
				double vx[NMAX], double vy[NMAX], double vz[NMAX])
{
	int i;
	FILE *out;

	out=fopen(fn, "w");

	fprintf(out, "%d\n3\n%lf\n",n,t);
	for(i=0;i<n;i++)
		fprintf(out, "%.8E\n", m[i]);
	for(i=0;i<n;i++)
		fprintf(out, "%.8E %.8E %.8E\n", x[i], y[i], z[i]);
	for(i=0;i<n;i++)
		fprintf(out, "%.8E %.8E %.8E\n", vx[i], vy[i], vz[i]);
	fclose(out);
}

void writedata(char *fn, int n, double pot[NMAX], double ax[NMAX], double ay[NMAX], double az[NMAX])
{
	int i;
	FILE *out=fopen(fn, "wt");

	for(i=0;i<n;i++)
		fprintf(out, "%d %.8E %.8E %.8E 0 0 0\n", i, ax[i], ay[i], az[i]);
//		fprintf(out, "%d %.8E %.8E %.8E %.8E %.8E %.8E %.8E\n", i, pot[i], ax[i], ay[i], az[i], jx[i], jy[i], jz[i]);

	fclose(out);
}
