#include "spu.h"


inline void dma_get(unsigned long long ea, volatile void *lsa, int size, int tag)
{
	int offset=0;
	for(;size>DMAMAX;size-=DMAMAX)
	{
		spu_mfcdma64(lsa+offset, mfc_ea2h(ea+offset), mfc_ea2l(ea+offset), DMAMAX, tag, MFC_GET_CMD);
		offset+=DMAMAX;
	}
	spu_mfcdma64(lsa+offset, mfc_ea2h(ea+offset), mfc_ea2l(ea+offset), size, tag, MFC_GET_CMD);
}

inline void dma_put(void *lsa, unsigned long long ea, int size, int tag)
{
	int offset=0;
	for(;size>DMAMAX;size-=DMAMAX)
	{
		spu_mfcdma64(lsa+offset, mfc_ea2h(ea+offset), mfc_ea2l(ea+offset), DMAMAX, tag, MFC_PUT_CMD);
		offset+=DMAMAX;
	}
	spu_mfcdma64(lsa+offset, mfc_ea2h(ea+offset), mfc_ea2l(ea+offset), size, tag, MFC_PUT_CMD);
}

inline void dma_put_fence(void *lsa, unsigned long long ea, int size, int tag)
{
	int offset=0;
	for(;size>DMAMAX;size-=DMAMAX)
	{
		spu_mfcdma64(lsa+offset, mfc_ea2h(ea+offset), mfc_ea2l(ea+offset), DMAMAX, tag, MFC_PUTF_CMD);
		offset+=DMAMAX;
	}
	spu_mfcdma64(lsa+offset, mfc_ea2h(ea+offset), mfc_ea2l(ea+offset), size, tag, MFC_PUTF_CMD);
}

inline void dma_wait(int tag)
{
	spu_writech(MFC_WrTagMask, 1<< tag);
	spu_mfcstat(MFC_TAG_UPDATE_ALL);
}

