#include "spu.h"

int gi=0;

void calcforce_core(int id, int buf, int ns, float eps2, float xi[IBUF], float yi[IBUF], float zi[IBUF],
					  int nj, float mj[JMAX], float xj[JMAX], float yj[JMAX], float zj[JMAX],
					  float pot[IBUF], float ax[IBUF], float ay[IBUF], float az[IBUF])
{
	int i, j, offset=ISET*buf;
	vector float veps2;
	const vector float cns0 = {0.0f,0.0f,0.0f,0.0f};
	const vector float cns05 = {0.5f,0.5f,0.5f,0.5f};
	const vector float cns3 = {3.0f,3.0f,3.0f,3.0f};
	const vector unsigned int rupi={1,1,1,1};
	vector float rup;
	const vector unsigned char pattern = {0x00,0x01,0x02,0x03, 0x08,0x09,0x0a,0x0b,
									0x04,0x05,0x06,0x07, 0x0c,0x0d,0x0e,0x0f};
	const vector unsigned char combine = {0x00,0x01,0x02,0x03, 0x14,0x15,0x16,0x17,
									0x08,0x09,0x0a,0x0b, 0x1c,0x1d,0x1e,0x1f};
	const vector unsigned char spl0 = {0x00,0x01,0x02,0x03, 0x00,0x01,0x02,0x03,
								 0x00,0x01,0x02,0x03, 0x00,0x01,0x02,0x03};	
	const vector unsigned char spl1 = {0x04,0x05,0x06,0x07, 0x04,0x05,0x06,0x07,
								 0x04,0x05,0x06,0x07, 0x04,0x05,0x06,0x07};
	const vector unsigned char spl2 = {0x08,0x09,0x0a,0x0b, 0x08,0x09,0x0a,0x0b,
								 0x08,0x09,0x0a,0x0b, 0x08,0x09,0x0a,0x0b};
	const vector unsigned char spl3 = {0x0c,0x0d,0x0e,0x0f, 0x0c,0x0d,0x0e,0x0f,
								 0x0c,0x0d,0x0e,0x0f, 0x0c,0x0d,0x0e,0x0f};
	vector float *xiv, *yiv, *ziv, *vxiv, *vyiv, *vziv, *potv, *axiv, *ayiv, *aziv;
	vector float *mjv, *xjv, *yjv, *zjv;
	vector float x_ia, y_ia, z_ia, x_ib, y_ib, z_ib;
	vector float mjt, xjt, yjt, zjt;
	vector float m_j0, m_j1, m_j2, m_j3;
	vector float x_j0, x_j1, x_j2, x_j3;
	vector float y_j0, y_j1, y_j2, y_j3;
	vector float z_j0, z_j1, z_j2, z_j3;
	vector float r0xa, r0ya, r0za, r0xb, r0yb, r0zb;
	vector float r1xa, r1ya, r1za, r1xb, r1yb, r1zb;
	vector float r2xa, r2ya, r2za, r2xb, r2yb, r2zb;
	vector float r3xa, r3ya, r3za, r3xb, r3yb, r3zb;
	vector float r02xa, r02ya, r02a, r02xb, r02yb, r02b;
	vector float r12xa, r12ya, r12a, r12xb, r12yb, r12b;
	vector float r22xa, r22ya, r22a, r22xb, r22yb, r22b;
	vector float r32xa, r32ya, r32a, r32xb, r32yb, r32b;
	vector float ri0a, ri0ea, ri02a, ri0ha, ri0ta;
	vector float ri0b, ri0eb, ri02b, ri0hb, ri0tb;
	vector float ri1a, ri1ea, ri12a, ri1ha, ri1ta;
	vector float ri1b, ri1eb, ri12b, ri1hb, ri1tb;
	vector float ri2a, ri2ea, ri22a, ri2ha, ri2ta;
	vector float ri2b, ri2eb, ri22b, ri2hb, ri2tb;
	vector float ri3a, ri3ea, ri32a, ri3ha, ri3ta;
	vector float ri3b, ri3eb, ri32b, ri3hb, ri3tb;
	vector float pot0a, r2i0a, mr3i0a, pot0b, r2i0b, mr3i0b;
	vector float pot1a, r2i1a, mr3i1a, pot1b, r2i1b, mr3i1b;
	vector float pot2a, r2i2a, mr3i2a, pot2b, r2i2b, mr3i2b;
	vector float pot3a, r2i3a, mr3i3a, pot3b, r2i3b, mr3i3b;
	vector float potta, pott1a, pott2a, pottb, pott1b, pott2b;
	vector float pota, axa, aya, aza, potb, axb, ayb, azb;
	rup=(vector float)rupi;
	veps2=spu_splats(eps2);
	xiv = (vector float*)&(xi[offset]);
	yiv = (vector float*)&(yi[offset]);
	ziv = (vector float*)&(zi[offset]);
	potv = (vector float*)&(pot[offset]);
	axiv = (vector float*)&(ax[offset]);
	ayiv = (vector float*)&(ay[offset]);
	aziv = (vector float*)&(az[offset]);

	for(i=0;__builtin_expect(i<ns,1);i+=8)
	{
		x_ia=*(xiv++);
		y_ia=*(yiv++);
		z_ia=*(ziv++);
		x_ib=*(xiv++);
		y_ib=*(yiv++);
		z_ib=*(ziv++);
		mjv = (vector float*)&(mj[0]);
		xjv = (vector float*)&(xj[0]);
		yjv = (vector float*)&(yj[0]);
		zjv = (vector float*)&(zj[0]);
		axa=axb=cns0;
		aya=ayb=cns0;
		aza=azb=cns0;
		pota=potb=cns0;
		for(j=0;__builtin_expect(j<nj,1);j+=4)
		{
			mjt=*(mjv++);
			xjt=*(xjv++);
			yjt=*(yjv++);
			zjt=*(zjv++);
			m_j0=spu_shuffle(mjt, mjt, spl0);
			m_j1=spu_shuffle(mjt, mjt, spl1);
			m_j2=spu_shuffle(mjt, mjt, spl2);
			m_j3=spu_shuffle(mjt, mjt, spl3);
			x_j0=spu_shuffle(xjt, xjt, spl0);
			x_j1=spu_shuffle(xjt, xjt, spl1);
			x_j2=spu_shuffle(xjt, xjt, spl2);
			x_j3=spu_shuffle(xjt, xjt, spl3);
			y_j0=spu_shuffle(yjt, yjt, spl0);
			y_j1=spu_shuffle(yjt, yjt, spl1);
			y_j2=spu_shuffle(yjt, yjt, spl2);
			y_j3=spu_shuffle(yjt, yjt, spl3);
			z_j0=spu_shuffle(zjt, zjt, spl0);
			z_j1=spu_shuffle(zjt, zjt, spl1);
			z_j2=spu_shuffle(zjt, zjt, spl2);
			z_j3=spu_shuffle(zjt, zjt, spl3);

			r0xa = spu_sub(x_j0, x_ia); // xj - xi
			r0ya = spu_sub(y_j0, y_ia); // yj - yi
			r0za = spu_sub(z_j0, z_ia); // zj - zi
			r1xa = spu_sub(x_j1, x_ia); // xj - xi
			r1ya = spu_sub(y_j1, y_ia); // yj - yi
			r1za = spu_sub(z_j1, z_ia); // zj - zi
			r2xa = spu_sub(x_j2, x_ia); // xj - xi
			r2ya = spu_sub(y_j2, y_ia); // yj - yi
			r2za = spu_sub(z_j2, z_ia); // zj - zi
			r3xa = spu_sub(x_j3, x_ia); // xj - xi
			r3ya = spu_sub(y_j3, y_ia); // yj - yi
			r3za = spu_sub(z_j3, z_ia); // zj - zi
			r0xb = spu_sub(x_j0, x_ib); // xj - xi
			r0yb = spu_sub(y_j0, y_ib); // yj - yi
			r0zb = spu_sub(z_j0, z_ib); // zj - zi
			r1xb = spu_sub(x_j1, x_ib); // xj - xi
			r1yb = spu_sub(y_j1, y_ib); // yj - yi
			r1zb = spu_sub(z_j1, z_ib); // zj - zi
			r2xb = spu_sub(x_j2, x_ib); // xj - xi
			r2yb = spu_sub(y_j2, y_ib); // yj - yi
			r2zb = spu_sub(z_j2, z_ib); // zj - zi
			r3xb = spu_sub(x_j3, x_ib); // xj - xi
			r3yb = spu_sub(y_j3, y_ib); // yj - yi
			r3zb = spu_sub(z_j3, z_ib); // zj - zi

			r02xa=spu_madd(r0xa,r0xa,veps2); //x*x+eps2
			r02ya=spu_madd(r0ya,r0ya,r02xa); //(y*y)+(x*x+eps2)
			r02a=spu_madd(r0za,r0za,r02ya); //(z*z)+((y*y)+(x*x)+eps2)
			r12xa=spu_madd(r1xa,r1xa,veps2); //x*x+eps2
			r12ya=spu_madd(r1ya,r1ya,r12xa); //(y*y)+(x*x+eps2)
			r12a=spu_madd(r1za,r1za,r12ya); //(z*z)+((y*y)+(x*x)+eps2)
			r22xa=spu_madd(r2xa,r2xa,veps2); //x*x+eps2
			r22ya=spu_madd(r2ya,r2ya,r22xa); //(y*y)+(x*x+eps2)
			r22a=spu_madd(r2za,r2za,r22ya); //(z*z)+((y*y)+(x*x)+eps2)
			r32xa=spu_madd(r3xa,r3xa,veps2); //x*x+eps2
			r32ya=spu_madd(r3ya,r3ya,r32xa); //(y*y)+(x*x+eps2)
			r32a=spu_madd(r3za,r3za,r32ya); //(z*z)+((y*y)+(x*x)+eps2)
			r02xb=spu_madd(r0xb,r0xb,veps2); //x*x+eps2
			r02yb=spu_madd(r0yb,r0yb,r02xb); //(y*y)+(x*x+eps2)
			r02b=spu_madd(r0zb,r0zb,r02yb); //(z*z)+((y*y)+(x*x)+eps2)
			r12xb=spu_madd(r1xb,r1xb,veps2); //x*x+eps2
			r12yb=spu_madd(r1yb,r1yb,r12xb); //(y*y)+(x*x+eps2)
			r12b=spu_madd(r1zb,r1zb,r12yb); //(z*z)+((y*y)+(x*x)+eps2)
			r22xb=spu_madd(r2xb,r2xb,veps2); //x*x+eps2
			r22yb=spu_madd(r2yb,r2yb,r22xb); //(y*y)+(x*x+eps2)
			r22b=spu_madd(r2zb,r2zb,r22yb); //(z*z)+((y*y)+(x*x)+eps2)
			r32xb=spu_madd(r3xb,r3xb,veps2); //x*x+eps2
			r32yb=spu_madd(r3yb,r3yb,r32xb); //(y*y)+(x*x+eps2)
			r32b=spu_madd(r3zb,r3zb,r32yb); //(z*z)+((y*y)+(x*x)+eps2)

			//NR-iteration
#ifdef NRITE
			ri0ea=spu_rsqrte(r02a); //estimate x0=sqrt(a)
			ri02a=spu_mul(ri0ea,ri0ea); 	//x02=x0*x0
			ri0ta=spu_nmsub(r02a,ri02a,cns3); //xt=-(x02*a-3)
			ri0a=spu_mul(ri0ea,ri0ta); //ri=xh*xt
			ri0eb=spu_rsqrte(r02b); //estimate x0=sqrt(a)
			ri02b=spu_mul(ri0eb,ri0eb); 	//x02=x0*x0
			ri0tb=spu_nmsub(r02b,ri02b,cns3); //xt=-(x02*a-3)
			ri0b=spu_mul(ri0eb,ri0tb); //ri=xh*xt
			ri1ea=spu_rsqrte(r12a); //estimate x1=sqrt(a)
			ri12a=spu_mul(ri1ea,ri1ea); 	//x12=x1*x1
			ri1ta=spu_nmsub(r12a,ri12a,cns3); //xt=-(x12*a-3)
			ri1a=spu_mul(ri1ea,ri1ta); //ri=xh*xt
			ri1eb=spu_rsqrte(r12b); //estimate x1=sqrt(a)
			ri12b=spu_mul(ri1eb,ri1eb); 	//x12=x1*x1
			ri1tb=spu_nmsub(r12b,ri12b,cns3); //xt=-(x12*a-3)
			ri1b=spu_mul(ri1eb,ri1tb); //ri=xh*xt
			ri2ea=spu_rsqrte(r22a); //estimate x2=sqrt(a)
			ri22a=spu_mul(ri2ea,ri2ea); 	//x22=x2*x2
			ri2ta=spu_nmsub(r22a,ri22a,cns3); //xt=-(x22*a-3)
			ri2a=spu_mul(ri2ea,ri2ta); //ri=xh*xt
			ri2eb=spu_rsqrte(r22b); //estimate x2=sqrt(a)
			ri22b=spu_mul(ri2eb,ri2eb); 	//x22=x2*x2
			ri2tb=spu_nmsub(r22b,ri22b,cns3); //xt=-(x22*a-3)
			ri2b=spu_mul(ri2eb,ri2tb); //ri=xh*xt
			ri3ea=spu_rsqrte(r32a); //estimate x3=sqrt(a)
			ri32a=spu_mul(ri3ea,ri3ea); 	//x32=x3*x3
			ri3ta=spu_nmsub(r32a,ri32a,cns3); //xt=-(x32*a-3)
			ri3a=spu_mul(ri3ea,ri3ta); //ri=xh*xt
			ri3eb=spu_rsqrte(r32b); //estimate x3=sqrt(a)
			ri32b=spu_mul(ri3eb,ri3eb); 	//x32=x3*x3
			ri3tb=spu_nmsub(r32b,ri32b,cns3); //xt=-(x32*a-3)
			ri3b=spu_mul(ri3eb,ri3tb); //ri=xh*xt
#else
			ri0a=spu_rsqrte(r02a); //estimate x0=sqrt(a)
			ri1a=spu_rsqrte(r12a); //estimate x0=sqrt(a)
			ri2a=spu_rsqrte(r22a); //estimate x0=sqrt(a)
			ri3a=spu_rsqrte(r32a); //estimate x0=sqrt(a)
			ri0b=spu_rsqrte(r02b); //estimate x0=sqrt(a)
			ri1b=spu_rsqrte(r12b); //estimate x0=sqrt(a)
			ri2b=spu_rsqrte(r22b); //estimate x0=sqrt(a)
			ri3b=spu_rsqrte(r32b); //estimate x0=sqrt(a)
#endif
			pot0a=spu_mul(ri0a, m_j0); //m/r
			r2i0a=spu_mul(ri0a,ri0a); //1/r^2
			mr3i0a=spu_mul(pot0a,r2i0a); //m/r^3
			pot1a=spu_mul(ri1a, m_j1); //m/r
			r2i1a=spu_mul(ri1a,ri1a); //1/r^2
			mr3i1a=spu_mul(pot1a,r2i1a); //m/r^3
			pot2a=spu_mul(ri2a, m_j2); //m/r
			r2i2a=spu_mul(ri2a,ri2a); //1/r^2
			mr3i2a=spu_mul(pot2a,r2i2a); //m/r^3
			pot3a=spu_mul(ri3a, m_j3); //m/r
			r2i3a=spu_mul(ri3a,ri3a); //1/r^2
			mr3i3a=spu_mul(pot3a,r2i3a); //m/r^3
			pot0b=spu_mul(ri0b, m_j0); //m/r
			r2i0b=spu_mul(ri0b,ri0b); //1/r^2
			mr3i0b=spu_mul(pot0b,r2i0b); //m/r^3
			pot1b=spu_mul(ri1b, m_j1); //m/r
			r2i1b=spu_mul(ri1b,ri1b); //1/r^2
			mr3i1b=spu_mul(pot1b,r2i1b); //m/r^3
			pot2b=spu_mul(ri2b, m_j2); //m/r
			r2i2b=spu_mul(ri2b,ri2b); //1/r^2
			mr3i2b=spu_mul(pot2b,r2i2b); //m/r^3
			pot3b=spu_mul(ri3b, m_j3); //m/r
			r2i3b=spu_mul(ri3b,ri3b); //1/r^2
			mr3i3b=spu_mul(pot3b,r2i3b); //m/r^3
#ifndef ROUNDUP
			pott1a=spu_add(pot0a,pot1a);
			pott2a=spu_add(pot2a,pot3a);
			potta=spu_add(pott1a,pott2a);
			pota=spu_sub(pota,potta);
			pott1b=spu_add(pot0b,pot1b);
			pott2b=spu_add(pot2b,pot3b);
			pottb=spu_add(pott1b,pott2b);
			potb=spu_sub(potb,pottb);

			axa=spu_madd(r0xa,mr3i0a,axa); //m*rx/r^3
			aya=spu_madd(r0ya,mr3i0a,aya); //m*rx/r^3
			aza=spu_madd(r0za,mr3i0a,aza); //m*rx/r^3
			axb=spu_madd(r0xb,mr3i0b,axb); //m*rx/r^3
			ayb=spu_madd(r0yb,mr3i0b,ayb); //m*rx/r^3
			azb=spu_madd(r0zb,mr3i0b,azb); //m*rx/r^3
			axa=spu_madd(r1xa,mr3i1a,axa); //m*rx/r^3
			aya=spu_madd(r1ya,mr3i1a,aya); //m*rx/r^3
			aza=spu_madd(r1za,mr3i1a,aza); //m*rx/r^3
			axb=spu_madd(r1xb,mr3i1b,axb); //m*rx/r^3
			ayb=spu_madd(r1yb,mr3i1b,ayb); //m*rx/r^3
			azb=spu_madd(r1zb,mr3i1b,azb); //m*rx/r^3
			axa=spu_madd(r2xa,mr3i2a,axa); //m*rx/r^3
			aya=spu_madd(r2ya,mr3i2a,aya); //m*rx/r^3
			aza=spu_madd(r2za,mr3i2a,aza); //m*rx/r^3
			axb=spu_madd(r2xb,mr3i2b,axb); //m*rx/r^3
			ayb=spu_madd(r2yb,mr3i2b,ayb); //m*rx/r^3
			azb=spu_madd(r2zb,mr3i2b,azb); //m*rx/r^3
			axa=spu_madd(r3xa,mr3i3a,axa); //m*rx/r^3
			aya=spu_madd(r3ya,mr3i3a,aya); //m*rx/r^3
			aza=spu_madd(r3za,mr3i3a,aza); //m*rx/r^3
			axb=spu_madd(r3xb,mr3i3b,axb); //m*rx/r^3
			ayb=spu_madd(r3yb,mr3i3b,ayb); //m*rx/r^3
			azb=spu_madd(r3zb,mr3i3b,azb); //m*rx/r^3
#else
			pota=spu_sel(spu_sub(pota,pot0a),rup,rupi);
			potb=spu_sel(spu_sub(potb,pot0b),rup,rupi);
			pota=spu_sel(spu_sub(pota,pot1a),rup,rupi);
			potb=spu_sel(spu_sub(potb,pot1b),rup,rupi);
			pota=spu_sel(spu_sub(pota,pot2a),rup,rupi);
			potb=spu_sel(spu_sub(potb,pot2b),rup,rupi);
			pota=spu_sel(spu_sub(pota,pot3a),rup,rupi);
			potb=spu_sel(spu_sub(potb,pot3b),rup,rupi);
			axa=spu_sel(spu_madd(r0xa,mr3i0a,axa),rup,rupi); //m*rx/r^3
			aya=spu_sel(spu_madd(r0ya,mr3i0a,aya),rup,rupi); //m*rx/r^3
			aza=spu_sel(spu_madd(r0za,mr3i0a,aza),rup,rupi); //m*rx/r^3
			axb=spu_sel(spu_madd(r0xb,mr3i0b,axb),rup,rupi); //m*rx/r^3
			ayb=spu_sel(spu_madd(r0yb,mr3i0b,ayb),rup,rupi); //m*rx/r^3
			azb=spu_sel(spu_madd(r0zb,mr3i0b,azb),rup,rupi); //m*rx/r^3
			axa=spu_sel(spu_madd(r1xa,mr3i1a,axa),rup,rupi); //m*rx/r^3
			aya=spu_sel(spu_madd(r1ya,mr3i1a,aya),rup,rupi); //m*rx/r^3
			aza=spu_sel(spu_madd(r1za,mr3i1a,aza),rup,rupi); //m*rx/r^3
			axb=spu_sel(spu_madd(r1xb,mr3i1b,axb),rup,rupi); //m*rx/r^3
			ayb=spu_sel(spu_madd(r1yb,mr3i1b,ayb),rup,rupi); //m*rx/r^3
			azb=spu_sel(spu_madd(r1zb,mr3i1b,azb),rup,rupi); //m*rx/r^3
			axa=spu_sel(spu_madd(r2xa,mr3i2a,axa),rup,rupi); //m*rx/r^3
			aya=spu_sel(spu_madd(r2ya,mr3i2a,aya),rup,rupi); //m*rx/r^3
			aza=spu_sel(spu_madd(r2za,mr3i2a,aza),rup,rupi); //m*rx/r^3
			axb=spu_sel(spu_madd(r2xb,mr3i2b,axb),rup,rupi); //m*rx/r^3
			ayb=spu_sel(spu_madd(r2yb,mr3i2b,ayb),rup,rupi); //m*rx/r^3
			azb=spu_sel(spu_madd(r2zb,mr3i2b,azb),rup,rupi); //m*rx/r^3
			axa=spu_sel(spu_madd(r3xa,mr3i3a,axa),rup,rupi); //m*rx/r^3
			aya=spu_sel(spu_madd(r3ya,mr3i3a,aya),rup,rupi); //m*rx/r^3
			aza=spu_sel(spu_madd(r3za,mr3i3a,aza),rup,rupi); //m*rx/r^3
			axb=spu_sel(spu_madd(r3xb,mr3i3b,axb),rup,rupi); //m*rx/r^3
			ayb=spu_sel(spu_madd(r3yb,mr3i3b,ayb),rup,rupi); //m*rx/r^3
			azb=spu_sel(spu_madd(r3zb,mr3i3b,azb),rup,rupi); //m*rx/r^3
#endif
#ifdef PAIRDEBUG
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+0, j+0, ACCCOR*spu_extract(spu_mul(r0xa,mr3i0a),0), ACCCOR*spu_extract(spu_mul(r0ya,mr3i0a),0), ACCCOR*spu_extract(spu_mul(r0za,mr3i0a),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+0, j+1, ACCCOR*spu_extract(spu_mul(r1xa,mr3i1a),0), ACCCOR*spu_extract(spu_mul(r1ya,mr3i1a),0), ACCCOR*spu_extract(spu_mul(r1za,mr3i1a),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+0, j+2, ACCCOR*spu_extract(spu_mul(r2xa,mr3i2a),0), ACCCOR*spu_extract(spu_mul(r2ya,mr3i2a),0), ACCCOR*spu_extract(spu_mul(r2za,mr3i2a),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+0, j+3, ACCCOR*spu_extract(spu_mul(r3xa,mr3i3a),0), ACCCOR*spu_extract(spu_mul(r3ya,mr3i3a),0), ACCCOR*spu_extract(spu_mul(r3za,mr3i3a),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+1, j+0, ACCCOR*spu_extract(spu_mul(r0xa,mr3i0a),1), ACCCOR*spu_extract(spu_mul(r0ya,mr3i0a),1), ACCCOR*spu_extract(spu_mul(r0za,mr3i0a),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+1, j+1, ACCCOR*spu_extract(spu_mul(r1xa,mr3i1a),1), ACCCOR*spu_extract(spu_mul(r1ya,mr3i1a),1), ACCCOR*spu_extract(spu_mul(r1za,mr3i1a),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+1, j+2, ACCCOR*spu_extract(spu_mul(r2xa,mr3i2a),1), ACCCOR*spu_extract(spu_mul(r2ya,mr3i2a),1), ACCCOR*spu_extract(spu_mul(r2za,mr3i2a),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+1, j+3, ACCCOR*spu_extract(spu_mul(r3xa,mr3i3a),1), ACCCOR*spu_extract(spu_mul(r3ya,mr3i3a),1), ACCCOR*spu_extract(spu_mul(r3za,mr3i3a),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+2, j+0, ACCCOR*spu_extract(spu_mul(r0xa,mr3i0a),2), ACCCOR*spu_extract(spu_mul(r0ya,mr3i0a),2), ACCCOR*spu_extract(spu_mul(r0za,mr3i0a),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+2, j+1, ACCCOR*spu_extract(spu_mul(r1xa,mr3i1a),2), ACCCOR*spu_extract(spu_mul(r1ya,mr3i1a),2), ACCCOR*spu_extract(spu_mul(r1za,mr3i1a),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+2, j+2, ACCCOR*spu_extract(spu_mul(r2xa,mr3i2a),2), ACCCOR*spu_extract(spu_mul(r2ya,mr3i2a),2), ACCCOR*spu_extract(spu_mul(r2za,mr3i2a),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+2, j+3, ACCCOR*spu_extract(spu_mul(r3xa,mr3i3a),2), ACCCOR*spu_extract(spu_mul(r3ya,mr3i3a),2), ACCCOR*spu_extract(spu_mul(r3za,mr3i3a),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+3, j+0, ACCCOR*spu_extract(spu_mul(r0xa,mr3i0a),3), ACCCOR*spu_extract(spu_mul(r0ya,mr3i0a),3), ACCCOR*spu_extract(spu_mul(r0za,mr3i0a),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+3, j+1, ACCCOR*spu_extract(spu_mul(r1xa,mr3i1a),3), ACCCOR*spu_extract(spu_mul(r1ya,mr3i1a),3), ACCCOR*spu_extract(spu_mul(r1za,mr3i1a),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+3, j+2, ACCCOR*spu_extract(spu_mul(r2xa,mr3i2a),3), ACCCOR*spu_extract(spu_mul(r2ya,mr3i2a),3), ACCCOR*spu_extract(spu_mul(r2za,mr3i2a),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+3, j+3, ACCCOR*spu_extract(spu_mul(r3xa,mr3i3a),3), ACCCOR*spu_extract(spu_mul(r3ya,mr3i3a),3), ACCCOR*spu_extract(spu_mul(r3za,mr3i3a),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+4, j+0, ACCCOR*spu_extract(spu_mul(r0xb,mr3i0b),0), ACCCOR*spu_extract(spu_mul(r0yb,mr3i0b),0), ACCCOR*spu_extract(spu_mul(r0zb,mr3i0b),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+4, j+1, ACCCOR*spu_extract(spu_mul(r1xb,mr3i1b),0), ACCCOR*spu_extract(spu_mul(r1yb,mr3i1b),0), ACCCOR*spu_extract(spu_mul(r1zb,mr3i1b),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+4, j+2, ACCCOR*spu_extract(spu_mul(r2xb,mr3i2b),0), ACCCOR*spu_extract(spu_mul(r2yb,mr3i2b),0), ACCCOR*spu_extract(spu_mul(r2zb,mr3i2b),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+4, j+3, ACCCOR*spu_extract(spu_mul(r3xb,mr3i3b),0), ACCCOR*spu_extract(spu_mul(r3yb,mr3i3b),0), ACCCOR*spu_extract(spu_mul(r3zb,mr3i3b),0));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+5, j+0, ACCCOR*spu_extract(spu_mul(r0xb,mr3i0b),1), ACCCOR*spu_extract(spu_mul(r0yb,mr3i0b),1), ACCCOR*spu_extract(spu_mul(r0zb,mr3i0b),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+5, j+1, ACCCOR*spu_extract(spu_mul(r1xb,mr3i1b),1), ACCCOR*spu_extract(spu_mul(r1yb,mr3i1b),1), ACCCOR*spu_extract(spu_mul(r1zb,mr3i1b),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+5, j+2, ACCCOR*spu_extract(spu_mul(r2xb,mr3i2b),1), ACCCOR*spu_extract(spu_mul(r2yb,mr3i2b),1), ACCCOR*spu_extract(spu_mul(r2zb,mr3i2b),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+5, j+3, ACCCOR*spu_extract(spu_mul(r3xb,mr3i3b),1), ACCCOR*spu_extract(spu_mul(r3yb,mr3i3b),1), ACCCOR*spu_extract(spu_mul(r3zb,mr3i3b),1));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+6, j+0, ACCCOR*spu_extract(spu_mul(r0xb,mr3i0b),2), ACCCOR*spu_extract(spu_mul(r0yb,mr3i0b),2), ACCCOR*spu_extract(spu_mul(r0zb,mr3i0b),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+6, j+1, ACCCOR*spu_extract(spu_mul(r1xb,mr3i1b),2), ACCCOR*spu_extract(spu_mul(r1yb,mr3i1b),2), ACCCOR*spu_extract(spu_mul(r1zb,mr3i1b),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+6, j+2, ACCCOR*spu_extract(spu_mul(r2xb,mr3i2b),2), ACCCOR*spu_extract(spu_mul(r2yb,mr3i2b),2), ACCCOR*spu_extract(spu_mul(r2zb,mr3i2b),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+6, j+3, ACCCOR*spu_extract(spu_mul(r3xb,mr3i3b),2), ACCCOR*spu_extract(spu_mul(r3yb,mr3i3b),2), ACCCOR*spu_extract(spu_mul(r3zb,mr3i3b),2));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+7, j+0, ACCCOR*spu_extract(spu_mul(r0xb,mr3i0b),3), ACCCOR*spu_extract(spu_mul(r0yb,mr3i0b),3), ACCCOR*spu_extract(spu_mul(r0zb,mr3i0b),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+7, j+1, ACCCOR*spu_extract(spu_mul(r1xb,mr3i1b),3), ACCCOR*spu_extract(spu_mul(r1yb,mr3i1b),3), ACCCOR*spu_extract(spu_mul(r1zb,mr3i1b),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+7, j+2, ACCCOR*spu_extract(spu_mul(r2xb,mr3i2b),3), ACCCOR*spu_extract(spu_mul(r2yb,mr3i2b),3), ACCCOR*spu_extract(spu_mul(r2zb,mr3i2b),3));
			fprintf(stderr, "%d %d %d %e %e %e\n", id, gi+7, j+3, ACCCOR*spu_extract(spu_mul(r3xb,mr3i3b),3), ACCCOR*spu_extract(spu_mul(r3yb,mr3i3b),3), ACCCOR*spu_extract(spu_mul(r3zb,mr3i3b),3));
#endif
		}
		*potv++=pota;
		*axiv++=axa;
		*ayiv++=aya;
		*aziv++=aza;
		*potv++=potb;
		*axiv++=axb;
		*ayiv++=ayb;
		*aziv++=azb;
		gi+=8;
	}
}
