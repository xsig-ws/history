#include "ppu.h"
#include "ppu_prof.h"

double	m[NMAX]		__ALIGNED_DMA__;
double	x[NMAX]		__ALIGNED_DMA__;
double	y[NMAX]		__ALIGNED_DMA__;
double	z[NMAX]		__ALIGNED_DMA__;
double	vx[NMAX]		__ALIGNED_DMA__;
double	vy[NMAX]		__ALIGNED_DMA__;
double	vz[NMAX]		__ALIGNED_DMA__;
double	ax[NMAX]		__ALIGNED_DMA__;
double	ay[NMAX]		__ALIGNED_DMA__;
double	az[NMAX]		__ALIGNED_DMA__;
double	axo[NMAX]		__ALIGNED_DMA__;
double	ayo[NMAX]		__ALIGNED_DMA__;
double	azo[NMAX]		__ALIGNED_DMA__;
double	pot[NMAX]		__ALIGNED_DMA__;


double calckenergy(int n, double m[NMAX], double vx[NMAX], double vy[NMAX], double vz[NMAX])
{
	int i=0;
	double e=0.0;
	for(i=0;i<n;i++)
		e+=0.5*(double)m[i]*((double)vx[i]*(double)vx[i]+(double)vy[i]*(double)vy[i]+(double)vz[i]*(double)vz[i]);
	return e;
}

double calcpenergy(int n, double m[NMAX], double x[NMAX], double y[NMAX], double z[NMAX], double eps2)
{
	int i=0, j=0;
	double e=0.0, dx, dy, dz;
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			dx=(double)x[i]-(double)x[j];
			dy=(double)y[i]-(double)y[j];
			dz=(double)z[i]-(double)z[j];
			e-=(double)m[i]*m[j]/sqrt(dx*dx+dy*dy+dz*dz+(double)eps2);
		}
	}
	return e;	
}

double calcpenergye(int n, double m[NMAX], double pot[NMAX])
{
	int i=0;
	double e=0.0;
	for(i=0;i<n;i++)
		e+=0.5*(double)m[i]*pot[i];
	return e;
}

double calctenergye(int n, double m[NMAX], double pot[NMAX],double vx[NMAX], double vy[NMAX], double vz[NMAX], double eps2)
{
	return calckenergy(n,m,vx,vy,vz)+calcpenergye(n,m,pot);
}

double calctenergy(int n, double m[NMAX], double pot[NMAX],double x[NMAX], double y[NMAX], double z[NMAX],
					 double vx[NMAX], double vy[NMAX], double vz[NMAX], double eps2)
{
	return calckenergy(n,m,vx,vy,vz)+calcpenergy(n,m,x,y,z,eps2);
}

int main(int argc, char **argv)
{
	int i,n;
	double eps2=EPS2;
	unsigned int mode=NONE, mes=NONE;
	double t=0.0, dt=DT, tmax=TMAX, e, e0;
	spe_t spe[NUMSPE] __ALIGNED_16__;
#ifdef PROFILE
	unsigned int ts, te,k=2;
#endif
	//start SPE
	initspe(spe);

	//load data
	if(argc<2)
		argv[1]="n4k.dat";
	if(argc<3)
		argv[2]="out.txt";
	if(argc>=4)
		dt=strtod(argv[3],NULL);
	if(argc>=5)
		tmax=strtod(argv[4],NULL);

	readnemo(argv[1], &n, m, x, y, z, vx, vy, vz);
	if(n>NMAX)
	{
		fprintf(stderr, "too many particles\n");
		return 1;
	}
	fprintf(stderr, "n=%d, tmax=%f, dt=%f\n", n, tmax, dt);
#ifdef PPEDEBUG
	fprintf(stderr, "PPEDEBUG: load %s:%d particles\n", argv[1], n);
#endif
	//integration loop
	setjp(spe, n, m, x, y, z);
	calcforce(spe, n, eps2, x, y, z, pot, ax, ay, az);
	e0=calctenergy(n,m,pot,x,y,z,vx,vy,vz,eps2);
	for(i=0;i<n;i++)
	{
		vx[i]+=dt*0.5*ax[i];
		vy[i]+=dt*0.5*ay[i];
		vz[i]+=dt*0.5*az[i];
	}
	while(t<tmax)
	{
		//integrate
		for(i=0;i<n;i++)
		{
			x[i]+=vx[i]*dt;
			y[i]+=vy[i]*dt;
			z[i]+=vz[i]*dt;
		}
		t+=dt;
		//send j-particles
		setjp(spe, n, m, x, y, z);
		//send i-particles & calc force
		calcforce(spe, n, eps2, x, y, z, pot, ax, ay, az);
		for(i=0;i<n;i++)
		{
			vx[i]+=ax[i]*dt;
			vy[i]+=ay[i]*dt;
			vz[i]+=az[i]*dt;
		}
	}
	for(i=0;i<n;i++)
	{
		x[i]+=vx[i]*dt;
		y[i]+=vy[i]*dt;
		z[i]+=vz[i]*dt;
	}
#ifdef PROFILE
	StartProf(ts);
#endif
	setjp(spe, n, m, x, y, z);
	calcforce(spe, n, eps2, x, y, z, pot, ax, ay, az);
#ifdef PROFILE
	StopProf(te,ts);
#endif
	for(i=0;i<n;i++)
	{
		vx[i]+=ax[i]*dt*0.5;
		vy[i]+=ay[i]*dt*0.5;
		vz[i]+=az[i]*dt*0.5;
	}
	e=calctenergy(n,m,pot,x,y,z,vx,vy,vz,eps2);
	printf("E0=%e E=%e DE/E=%e\n", e0, e, (e0-e)/e0);
#ifdef PROFILE
	PrintProf(te);
	fprintf(stderr, "%f Gflops\n", 38.0*(double)n*(double)n/1000000000.0/((double)te/(double)TIMEBASE));
#endif
	writenemo(argv[2], n, t, m, x, y, z, vx, vy, vz);
#ifdef PPEDEBUG
	fprintf(stderr, "PPEDEBUG: write %s:%d particles\n", argv[2], n);
#endif
	//finalize
	finalize(spe);
	return 0;
}

