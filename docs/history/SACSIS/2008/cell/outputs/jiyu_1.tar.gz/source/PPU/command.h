#ifndef COMMAND_H_
#define COMMAND_H_

//PPE to SPE
#define NONE			(0)
#define WAIT			(1)
#define SETJP			(3)
#define CALCFORCE	(4)
#define FINISH		(100)
#define PUTRES		(128)

//SPE to PPE
#define IDLE			(11)
#define ENDSI			(12)
#define ENDJP			(13)
#define ENDCF			(14)

#define ENDPUT		(256)



#endif

