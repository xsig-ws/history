#ifndef PPU_H_
#define PPU_H_

#define PROFILE

#include <stdio.h>
#include <math.h>
#include <assert.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include "libspe2.h"
#include "common.h"
#include "command.h"
#include "params.h"

extern spe_program_handle_t SPU;

typedef struct {
	pthread_t pth;
	spe_context_ptr_t ctx;
	cmdjp_t cmdjp __ALIGNED_16__;
	cmdcf_t cmdcf __ALIGNED_16__;
	params_t p __ALIGNED_16__;
	volatile unsigned int psig1 __ALIGNED_16__;
	volatile unsigned int psig2 __ALIGNED_16__;
} spe_t;



void *spe_start(void *p);
void sendall(spe_t spe[NUMSPE], unsigned int m);
void waitall(spe_t spe[NUMSPE], unsigned int m);
void initspe(spe_t spe[NUMSPE]);
void setjp(spe_t spe[NUMSPE], int n, double mj[NMAX], double xj[NMAX], double yj[NMAX], double zj[NMAX]);
void calcforce(spe_t spe[NUMSPE], int n, double eps2, double xi[NMAX], double yi[NMAX], double zi[NMAX],
				 double pot[NMAX], double ax[NMAX], double ay[NMAX], double az[NMAX]);
void finalize(spe_t spe[NUMSPE]);

void readnemo(char *fn, int *n, double m[NMAX], double x[NMAX], double y[NMAX], double z[NMAX],
				double vx[NMAX], double vy[NMAX], double vz[NMAX]);
void writedata(char *fn, int n, double pot[NMAX], double ax[NMAX], double ay[NMAX], double az[NMAX]);

#endif /*PPU_H_*/
