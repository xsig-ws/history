#include "spu.h"


void loadjp(cmdjp_t cmdjp, float mj[JMAX], float xj[JMAX], float yj[JMAX], float zj[JMAX])
{
	int i;
	dma_get(cmdjp.mj, mj, sizeof(float)*cmdjp.nj, 1);
	dma_get(cmdjp.xj, &xj[0], sizeof(float)*cmdjp.nj, 1);
	dma_get(cmdjp.yj, &yj[0], sizeof(float)*cmdjp.nj, 1);
	dma_get(cmdjp.zj, &zj[0], sizeof(float)*cmdjp.nj, 1);
	dma_wait(1);
	for(i=0;i<cmdjp.nj%4;i++)
		mj[cmdjp.nj+i]=0;
}


void calcforce(params_t p, cmdcf_t cf, int nj, float mj[JMAX], float xj[JMAX], float yj[JMAX], float zj[JMAX])
{
	int n=0;
	static unsigned int mode __ALIGNED_16__;
	static float xi[IBUF] __ALIGNED_DMA__;
	static float yi[IBUF] __ALIGNED_DMA__;
	static float zi[IBUF] __ALIGNED_DMA__;
	static float pot[IBUF] __ALIGNED_DMA__;
	static float ax[IBUF] __ALIGNED_DMA__;
	static float ay[IBUF] __ALIGNED_DMA__;
	static float az[IBUF] __ALIGNED_DMA__;
	int buf=0, bufs=0, siset=ISET*sizeof(float), offset=0;
	unsigned int pss=PUTRES;
	unsigned long long ps[2];
	ps[0]=p.psig1, ps[1]=p.psig2;
	mode=ENDPUT;

	dma_get(cf.xi, &(xi[bufs]), siset, buf);
	dma_get(cf.yi, &(yi[bufs]), siset, buf);
	dma_get(cf.zi, &(zi[bufs]), siset, buf);
	buf^=1;
	bufs=buf*ISET;
	for(n=ISET;n<cf.ni;n+=ISET)
	{
		//load i-particles
		offset=n*sizeof(float);
		dma_get(cf.xi+offset, &(xi[bufs]), siset, buf);
		dma_get(cf.yi+offset, &(yi[bufs]), siset, buf);
		dma_get(cf.zi+offset, &(zi[bufs]), siset, buf);
		buf^=1;
		bufs=buf*ISET;
		offset=buf*ISET*sizeof(float);
		dma_wait(buf);
#ifdef SPEDEBUG2
		fprintf(stderr, "SPEDEBUG: %d load i-particles %e %e %e\n", p.id, xi[bufs], yi[bufs], zi[bufs]);
		fflush(stderr);
#endif
		calcforce_core(p.id, buf, ISET, cf.eps2, xi, yi, zi, nj, mj, xj, yj, zj, pot, ax, ay, az);
		pss=PUTRES;
		do
		{
			dma_get(ps[buf], &pss, sizeof(int), 2);
			dma_wait(2);
		} while(pss!=NONE);
		dma_put(&(pot[bufs]), cf.pot+offset, siset, buf);
		dma_put(&(ax[bufs]), cf.ax+offset, siset, buf);
		dma_put(&(ay[bufs]), cf.ay+offset, siset, buf);
		dma_put(&(az[bufs]), cf.az+offset, siset, buf);
		dma_put_fence(&mode, ps[buf], sizeof(int), buf);
		
#ifdef SPEDEBUG2
		fprintf(stderr, "SPEDEBUG: %d put results %d %d\n", p.id, buf, n-ISET);
		fflush(stderr);
#endif
	}	
	buf^=1;
	bufs=buf*ISET;
	offset=buf*ISET*sizeof(float);
	dma_wait(buf);
#ifdef SPEDEBUG
	fprintf(stderr, "SPEDEBUG: %d load i-particles\n", p.id);
#endif
	calcforce_core(p.id, buf, ISET, cf.eps2, xi, yi, zi, nj, mj, xj, yj, zj, pot, ax, ay, az);
	pss=PUTRES;
	do
	{
		dma_get(ps[buf], &pss, sizeof(int), 2);
		dma_wait(2);
	} while(pss!=NONE);
	dma_put(&(pot[bufs]), cf.pot+offset, siset, buf);
	dma_put(&(ax[bufs]), cf.ax+offset, siset, buf);
	dma_put(&(ay[bufs]), cf.ay+offset, siset, buf);
	dma_put(&(az[bufs]), cf.az+offset, siset, buf);
	dma_put_fence(&mode, ps[buf], sizeof(int), buf);
	buf^=1;
	dma_wait(buf);
	buf^=1;
	dma_wait(buf);
#ifdef SPEDEBUG
	fprintf(stderr, "SPEDEBUG: %d put results %d %d\n", p.id, buf, n-ISET);
#endif
}
