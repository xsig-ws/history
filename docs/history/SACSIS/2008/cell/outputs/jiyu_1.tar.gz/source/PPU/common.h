#ifndef COMMON_H_
#define COMMON_H_

#define PPEDEBUG_
#define NRITE

#define NUMSPE	(6)
#define ISET		(32)
#define IBUF		(ISET*2)
#define JSET		(32)
#define JMAX_		(15360)
#define JMAX		(14400)
#define NMAX		(NUMSPE*JMAX)
#define DMAMAX	(16384)
#define __ALIGNED_DMA__ __attribute__((aligned(128)))
#define __ALIGNED_16__ __attribute__((aligned(16)))

#define EPS		(1.0f/256.0f)
#define EPS2		(EPS*EPS)

#define BIASCORRECT
#ifdef BIASCORRECT
#define BIAS		(-4.9e-8)
#else
#define BIAS		(0.0)
#endif
#ifdef NRITE
#define POTCOR	(0.5*(1.0-BIAS))
#define ACCCOR	(0.125*(1.0-3.0*BIAS))
#else
#define POTCOR	((1.0-BIAS))
#define ACCCOR	((1.0-3.0*BIAS))
#endif

typedef struct {
	int nj;
	unsigned long long mj;
	unsigned long long xj;
	unsigned long long yj;
	unsigned long long zj;
} __ALIGNED_16__ cmdjp_t;

typedef struct {
	int ni;
	float eps2;
	unsigned long long xi;
	unsigned long long yi;
	unsigned long long zi;
	unsigned long long pot;
	unsigned long long ax;
	unsigned long long ay;
	unsigned long long az;
} __ALIGNED_16__ cmdcf_t;

typedef struct {
	int id;
	unsigned long long cmdjp;
	unsigned long long cmdcf;
	unsigned long long psig1;
	unsigned long long psig2;
} __ALIGNED_16__ params_t;




#endif /*COMMON_H_*/
