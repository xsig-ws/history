#ifndef H_PPE_PROF_
#define H_PPE_PROF_

static inline unsigned long get_tbu(void)
{
   register unsigned long tbu;
   asm volatile("mftbu %0" : "=r"(tbu));
   return tbu;
}

static inline unsigned long get_tbl(void)
{
   register unsigned long tbl;
   asm volatile("mftb %0" : "=r"(tbl));
   return tbl;
}

static inline unsigned long long gettimeval(void)
{
   register unsigned long tbu;
   register unsigned long tbl;
   do{
	tbu = get_tbu();
	tbl = get_tbl();
   }while(get_tbu() != tbu);
   return ((unsigned long long)tbu << 32 | (unsigned long long)tbl);
}

#define TIMEBASE        (7.98*1.0e7)
#define StartProf(ts)   {ts=(unsigned int)gettimeval();}
#define StopProf(te,ts) {unsigned int temptime=(unsigned int)gettimeval();te=temptime-ts;}
#define PrintProf(te)   {fprintf(stderr, "time: %f(msec)\n", te/TIMEBASE*1.0e3);}
#endif
